import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Layout from './components/Layout';
import Home from './pages/Home';
import Projects from './pages/Projects';
import ComingSoon from './pages/ComingSoon';

function App() {
  return (
    <Router>
      <Layout>
        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/projects" element={<Projects />} />
          <Route path="/groups" element={<ComingSoon pageName="Groups" />} />
          <Route path="/issues" element={<ComingSoon pageName="Issues" />} />
          <Route path="/merge-requests" element={<ComingSoon pageName="Merge Requests" />} />
          <Route path="/todos" element={<ComingSoon pageName="To-Do List" />} />
          <Route path="/milestones" element={<ComingSoon pageName="Milestones" />} />
          <Route path="/snippets" element={<ComingSoon pageName="Snippets" />} />
          <Route path="/activity" element={<ComingSoon pageName="Activity" />} />
          <Route path="/import" element={<ComingSoon pageName="Import History" />} />
          <Route path="/workspaces" element={<ComingSoon pageName="Workspaces" />} />
          <Route path="/environments" element={<ComingSoon pageName="Environments" />} />
          <Route path="/operations" element={<ComingSoon pageName="Operations" />} />
          <Route path="/security" element={<ComingSoon pageName="Security" />} />
        </Routes>
      </Layout>
    </Router>
  );
}

export default App;
