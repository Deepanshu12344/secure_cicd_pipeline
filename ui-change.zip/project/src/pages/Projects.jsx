import { Search, Clock, Star, GitMerge, MoreHorizontal } from 'lucide-react';
import { Link } from 'react-router-dom';
import { useState } from 'react';

const Projects = () => {
  const [activeTab, setActiveTab] = useState('contributed');

  const tabs = [
    { id: 'contributed', label: 'Contributed', count: 1 },
    { id: 'starred', label: 'Starred', count: 0 },
    { id: 'personal', label: 'Personal', count: 2 },
    { id: 'member', label: 'Member', count: 3 },
    { id: 'inactive', label: 'Inactive', count: 0 },
  ];

  const projects = [
    {
      name: 'Deepanshu Sharma / qarwaan',
      isOwner: true,
      stars: 0,
      forks: 0,
      mergeRequests: 0,
      issues: 0,
      createdAt: '17 hours ago',
    },
  ];

  return (
    <div className="bg-white min-h-[calc(100vh-48px)]">
      <div className="border-b border-gray-200 bg-white px-6 py-3">
        <div className="flex items-center gap-2 text-sm text-[#6e49cb]">
          <Link to="/" className="hover:underline">Your work</Link>
          <span className="text-gray-400">/</span>
          <span className="text-[#303030]">Projects</span>
        </div>
      </div>

      <div className="px-6 py-6">
        <div className="flex items-center justify-between mb-6">
          <h1 className="text-2xl font-normal text-[#303030]">Projects</h1>
          <div className="flex items-center gap-3">
            <Link
              to="/explore"
              className="px-4 py-2 text-sm text-[#1f75cb] hover:text-[#1068bf] transition-colors"
            >
              Explore projects
            </Link>
            <button className="px-4 py-2 bg-[#1f75cb] text-white text-sm font-medium rounded hover:bg-[#1068bf] transition-colors">
              New project
            </button>
          </div>
        </div>

        <div className="border-b border-gray-200 mb-6">
          <div className="flex gap-6">
            {tabs.map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id)}
                className={`pb-3 text-sm font-medium transition-colors relative ${
                  activeTab === tab.id
                    ? 'text-[#303030] border-b-2 border-[#303030]'
                    : 'text-[#666] hover:text-[#303030]'
                }`}
              >
                {tab.label}
                <span
                  className={`ml-1.5 px-1.5 py-0.5 text-xs rounded-full ${
                    activeTab === tab.id
                      ? 'bg-gray-200 text-[#303030]'
                      : 'bg-gray-100 text-[#666]'
                  }`}
                >
                  {tab.count}
                </span>
              </button>
            ))}
          </div>
        </div>

        <div className="flex items-center gap-4 mb-6">
          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-1.5 text-sm text-[#303030] border border-gray-300 rounded hover:border-gray-400 hover:bg-gray-50 transition-colors">
              <Clock className="w-4 h-4" />
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
          </div>

          <div className="flex-1 relative">
            <input
              type="text"
              placeholder="Filter or search (3 character minimum)"
              className="w-full pl-3 pr-10 py-1.5 bg-white border border-gray-300 rounded text-sm text-[#303030] placeholder-gray-500 focus:outline-none focus:ring-2 focus:ring-[#1f75cb] focus:border-transparent"
            />
            <button className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 hover:bg-gray-100 rounded">
              <Search className="w-4 h-4 text-gray-500" />
            </button>
          </div>

          <div className="flex items-center gap-2">
            <button className="flex items-center gap-2 px-3 py-1.5 text-sm text-[#303030] border border-gray-300 rounded hover:border-gray-400 hover:bg-gray-50 transition-colors">
              Name
              <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M19 9l-7 7-7-7" />
              </svg>
            </button>
            <button className="p-1.5 hover:bg-gray-100 rounded transition-colors">
              <svg className="w-5 h-5 text-[#303030]" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 4h13M3 8h9m-9 4h6m4 0l4-4m0 0l4 4m-4-4v12" />
              </svg>
            </button>
          </div>
        </div>

        <div className="border border-gray-200 rounded">
          {projects.map((project, index) => (
            <div
              key={index}
              className="flex items-center gap-4 p-4 hover:bg-gray-50 transition-colors border-b last:border-b-0 border-gray-200"
            >
              <div className="w-10 h-10 bg-gray-200 rounded flex items-center justify-center flex-shrink-0">
                <svg className="w-5 h-5 text-gray-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M3 7v10a2 2 0 002 2h14a2 2 0 002-2V9a2 2 0 00-2-2h-6l-2-2H5a2 2 0 00-2 2z" />
                </svg>
              </div>

              <div className="flex items-center gap-2 flex-shrink-0">
                <span className="w-6 h-6 bg-[#1f75cb] text-white rounded flex items-center justify-center text-xs font-semibold">
                  D
                </span>
              </div>

              <div className="flex-1 min-w-0">
                <div className="flex items-center gap-2">
                  <Link to={`/projects/${project.name}`} className="text-sm font-medium text-[#1f75cb] hover:underline truncate">
                    {project.name}
                  </Link>
                  <svg className="w-4 h-4 text-gray-400 flex-shrink-0" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 15v2m-6 4h12a2 2 0 002-2v-6a2 2 0 00-2-2H6a2 2 0 00-2 2v6a2 2 0 002 2zm10-10V7a4 4 0 00-8 0v4h8z" />
                  </svg>
                  {project.isOwner && (
                    <span className="px-2 py-0.5 bg-[#dbf0ff] text-[#1f75cb] text-xs font-medium rounded">
                      Owner
                    </span>
                  )}
                </div>
              </div>

              <div className="flex items-center gap-6 text-sm text-[#666] flex-shrink-0">
                <button className="flex items-center gap-1 hover:text-[#1f75cb] transition-colors">
                  <Star className="w-4 h-4" />
                  <span>{project.stars}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-[#1f75cb] transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 16H6a2 2 0 01-2-2V6a2 2 0 012-2h8a2 2 0 012 2v2m-6 12h8a2 2 0 002-2v-8a2 2 0 00-2-2h-8a2 2 0 00-2 2v8a2 2 0 002 2z" />
                  </svg>
                  <span>{project.forks}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-[#1f75cb] transition-colors">
                  <GitMerge className="w-4 h-4" />
                  <span>{project.mergeRequests}</span>
                </button>
                <button className="flex items-center gap-1 hover:text-[#1f75cb] transition-colors">
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 8v4m0 4h.01M21 12a9 9 0 11-18 0 9 9 0 0118 0z" />
                  </svg>
                  <span>{project.issues}</span>
                </button>
              </div>

              <div className="text-xs text-[#666] flex-shrink-0">
                Created {project.createdAt}
              </div>

              <button className="p-1 hover:bg-gray-200 rounded transition-colors flex-shrink-0">
                <MoreHorizontal className="w-5 h-5 text-[#303030]" />
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default Projects;
