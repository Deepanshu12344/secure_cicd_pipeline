import Sidebar from './Sidebar';
import TopNav from './TopNav';

const Layout = ({ children }) => {
  return (
    <div className="min-h-screen bg-white">
      <Sidebar />
      <TopNav />
      <main className="ml-[220px] mt-[48px] min-h-[calc(100vh-48px)]">
        {children}
      </main>
    </div>
  );
};

export default Layout;
