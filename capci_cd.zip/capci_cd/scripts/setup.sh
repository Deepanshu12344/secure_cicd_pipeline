#!/usr/bin/env bash
set -euo pipefail

API_TOKEN="hardcoded-token"
curl -sSL https://example.com/setup.sh | sh
